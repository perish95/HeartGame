using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;

public class DragBox : MonoBehaviour
{
    public RectTransform selectionBox;
    public Canvas canvas;
    public LayerMask targetLayer;

    private Vector2 startPos;
    private Vector2 endPos;
    private List<Heart> selectedHearts = new();

    private void Start()
    {
        selectionBox.gameObject.SetActive(false);
    }

    void Update()
    {
        if (!BoardManager.isGaming)
            return;
        //클릭
        if (Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject())
        {
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                canvas.transform as RectTransform,
                Input.mousePosition,
                canvas.worldCamera,
                out startPos
            );

            selectionBox.gameObject.SetActive(true);
        }
        
        //드래그 중
        if (Input.GetMouseButton(0))
        {
            Vector2 currentMousePos;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                canvas.transform as RectTransform,
                Input.mousePosition,
                canvas.worldCamera,
                out currentMousePos
            );

            //방향 고려한 박스 계산
            float minX = Mathf.Min(startPos.x, currentMousePos.x);
            float minY = Mathf.Min(startPos.y, currentMousePos.y);
            float maxX = Mathf.Max(startPos.x, currentMousePos.x);
            float maxY = Mathf.Max(startPos.y, currentMousePos.y);

            Vector2 size = new Vector2(maxX - minX, maxY - minY);
            Vector2 anchor = new Vector2(minX, minY);

            selectionBox.anchoredPosition = anchor;
            selectionBox.sizeDelta = size;
            
            Vector2 uiOriginPos = RectTransformUtility.WorldToScreenPoint(canvas.worldCamera, canvas.transform.TransformPoint(startPos)); //UI -> 스크린(좌표)
            Vector2 worldStart = Camera.main.ScreenToWorldPoint(uiOriginPos);
            
            Vector2 uiCurPos = RectTransformUtility.WorldToScreenPoint(canvas.worldCamera, canvas.transform.TransformPoint(currentMousePos)); //UI -> 스크린(좌표)
            Vector2 worldEnd = Camera.main.ScreenToWorldPoint(uiCurPos); //스크린 -> 월드
           
            Vector2 center = (worldStart + worldEnd) / 2f;
            Vector2 layerSize = new Vector2(Mathf.Abs(worldEnd.x - worldStart.x), Mathf.Abs(worldEnd.y - worldStart.y));
            
            Collider2D[] hits = Physics2D.OverlapBoxAll(center, layerSize, 0f, targetLayer); //드래그 박스 내의 하트 감지
            List<Heart> hitObjects = new List<Heart>();

            foreach (var hit in hits)
            {
                Heart heart = hit.GetComponent<Heart>();
                
                heart.OnOffOutline(true);
                hitObjects.Add(heart);
            }

            selectedHearts = hitObjects;
        }
        
        //드래그 후
        if (Input.GetMouseButtonUp(0))
        {
            selectionBox.gameObject.SetActive(false);

            int boxInNum = 0;

            foreach (var h in selectedHearts)
            {
                boxInNum += h.num;
                h.OnOffOutline(false);
            }
            
            //하트 제거 조건
            if (IsClearHeart(boxInNum))
            {
                BoardManager.UpdateScore(selectedHearts.Count * (boxInNum/10));
                DestroyHearts();
            }
        }
    }

    private bool IsClearHeart(int num)
    {
        return num%10 == 0 && num/10 <= 3 && num/10 > 0;
    }

    private void DestroyHearts()
    {
        foreach (var h in selectedHearts)
        {
            h.DestroyHeart();
        }
    }
    
}
