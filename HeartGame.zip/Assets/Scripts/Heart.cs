using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Heart : MonoBehaviour
{
    public int num { get; private set; }

    [SerializeField] private TextMeshProUGUI numText;
    [SerializeField] private Image outlineImage; //드래그 했을 때 테두리 이미지
    private SpriteOutline spriteOutline;
    //private bool isSelected = false;
    
    // Start is called before the first frame update
    void Start()
    {
        spriteOutline = GetComponent<SpriteOutline>();
        spriteOutline.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Init(int temp)
    {
        num = temp;
        numText.text = num.ToString();
    }

    public void DestroyHeart()
    {
        SoundManager.Instance.PlaySfx();
        Destroy(gameObject);
    }

    public void OnOffOutline(bool isOn)
    {
        spriteOutline.enabled = isOn;
    }
    
}
