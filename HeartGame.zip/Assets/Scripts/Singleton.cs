using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Singleton<T> : MonoBehaviour where T : MonoBehaviour
{
   private static T instance;
   private static object locking = new object();

   public static T Instance
   {
      get
      {
         if (appIsStop)
         {
            Debug.LogWarning($"[Singleton] Instance {typeof(T)} already destroyed on application quit" );
            return null;
         }

         lock (locking)
         {
            if (instance == null)
            {
               instance = (T)FindObjectOfType(typeof(T));

               if (FindObjectsOfType(typeof(T)).Length > 1)
               {
                  Debug.LogError("[Singleton] Something went really wrong - there should never be more than 1 singleton");
                  return instance;
               }

               if (instance == null)
               {
                  GameObject singleton = new GameObject();
                  instance = singleton.AddComponent<T>();
                  singleton.name = "(singleton) " + typeof(T).ToString();
                  
                  DontDestroyOnLoad(singleton);
                  
                  Debug.Log("[Singleton] An instance was created with DontDestroyOnLoad");
               }
               else
               {
                  Debug.Log("[Singleton] Using instance already created");
               }

            }
            return instance;
         }
      }
   }

   private static bool appIsStop = false;

   public void OnDestroy()
   {
      appIsStop = true;
   }
}
