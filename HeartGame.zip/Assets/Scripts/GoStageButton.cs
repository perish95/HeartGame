using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoStageButton : MonoBehaviour
{
    public void GoStageButtonClicked()
    {
        SceneChanger.Instance.GoToStageScene();
    }
}
