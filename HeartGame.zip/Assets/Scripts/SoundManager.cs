using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : Singleton<SoundManager>
{
    //public AudioClip bgmSource;
    public AudioClip sfxSource;
    //public AudioSource bgmAudioSource;
    public AudioSource sfxAudioSource;

    private void Start()
    {
      
    }

    public void PlaySfx()
    {
        sfxAudioSource.PlayOneShot(sfxSource);
    }
}
