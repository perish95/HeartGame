using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public class BoardManager : MonoBehaviour
{
    public static bool isGaming = true;
    
    [SerializeField] private int row;
    [SerializeField] private int column;
    [SerializeField] private float spacing;
    [SerializeField] private GameObject heartPrefab;
    [SerializeField] private Transform startPos; //하트 만드는 첫 위치
    [Header("UI")]
    [SerializeField] private Slider timer;
    [SerializeField] private TextMeshProUGUI scoreText;
    [SerializeField] private GameObject resultPanel;
    [SerializeField] private TextMeshProUGUI resultScoreText;
    
    private static event Action ScoreEvent;
    private List<Heart> hearts = new List<Heart>();
    private float timeLimit = 120f; 
    private float remainingTime = 0f;
    private static int score = 0;
    
    
    // Start is called before the first frame update
    void Start()
    {
        //Init
        SetGame(); 
        
    }

    // Update is called once per frame
    void Update()
    {
        if (remainingTime > 0f)
        {
            remainingTime -= Time.deltaTime;
            timer.value = remainingTime;
        }
        else
        {
            timer.value = 0;
            DisplayResult(); //결과 표시
        }
    }

    private void SetGame()
    {
        timer.maxValue = timeLimit;
        timer.value = timeLimit;
        remainingTime = timeLimit;
        scoreText.text = score.ToString();
        ScoreEvent += DisplayScore;
        resultPanel.SetActive(false);
        
        for (int i = 0; i < row; i++) //Set Board
        {
            for (int j = 0; j < column; j++)
            {
                Vector3 pos = startPos.position + new Vector3(i * spacing, -j * spacing, 0); 
                Heart temp = Instantiate(heartPrefab,pos,Quaternion.identity).GetComponent<Heart>(); //위치도 정해서 만들어야 함
                
                temp.transform.SetParent(startPos);
                temp.Init(Random.Range(1, 10));
                hearts.Add(temp);
            }
        }
    }

    public static void UpdateScore(int num)
    {
        score += num;
        Debug.Log(score);
        ScoreEvent?.Invoke();
    }

    private void DisplayScore()
    {
        scoreText.text = score.ToString();
    }

    private void DisplayResult()
    {
        isGaming = false;
        resultPanel.SetActive(true);
        resultScoreText.text = score.ToString();
    }
}
