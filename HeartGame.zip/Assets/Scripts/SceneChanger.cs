using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChanger : Singleton<SceneChanger>
{
    //private AudioSource _audioSource;
    
    private void Awake()
    {
        DontDestroyOnLoad(gameObject);

        /*_audioSource = GetComponent<AudioSource>();
        if(_audioSource == null)
            Debug.Log("_audioSource Not found");
        
        _audioSource.Play();*/
    }

    public void GoToStageScene()
    {
        SceneManager.LoadScene(1);
    }

    public void GoToTitleScene()
    {
        SceneManager.LoadScene(0);
    }

}
